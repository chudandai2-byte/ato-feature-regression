# auto-feature-regression — Usage Guide (English)

> A one-stop **automated feature engineering + linear regression** skill for **regression tasks**. Feed it a raw dataset and it produces: a **bilingual (Chinese + English) report** covering preprocessing / feature engineering / modeling / evaluation, plus visualization charts and a reusable model.

---

## 1. Input

### 1.1 Required

| Item | Description |
|---|---|
| **Dataset file** | CSV / Excel / Parquet with 1 numeric target column + several feature columns. CSV encoding auto-detected (utf-8/gbk/latin-1) |
| **Target column** (`--target`) | Name of the numeric column to predict |

### 1.2 Key optional inputs

| Argument | When to use | Example |
|---|---|---|
| `--time-col` | **Mandatory for time-series data**; otherwise it degrades to a random split and distorts evaluation | `--time-col date` |
| `--exclude` | Drop ID/name non-feature columns, or leakage-prone target-derived columns | `--exclude id,shop_name` |
| `--context` | One line on the business context; written into the report and used to tailor chart notes | `--context "daily e-commerce ops data"` |
| `--goal` | One line on the modeling goal; chart notes revolve around it | `--goal "predict daily revenue & find key drivers"` |
| `--optimize-metric` | Metric that drives feature selection | `WMAPE`(default)/`MAE`/`RMSE`/`R2`/`Adj_R2` |
| `--feature-mode` | Feature construction mode | `auto`(default)/`custom`/`both` |
| `--custom-features` | Custom business feature formulas | `"gmv_ratio = ads_gmv/(ecomm_gmv+1)"` |
| `--interaction-pairs` | When you know which products carry business meaning | `"price*volume; ad_cost*ctr"` |
| `--impute` / `--impute-overrides` | Missing-value strategy (global / per-column) | `--impute-overrides "recharge:zero"` |
| `--log-target` | log1p transform switch for strongly right-skewed targets | `auto`(default)/`on`/`off` |
| `--outdir` | Output directory | `--outdir ./output` |

> See `SKILL.md` for the full argument list. First-time setup:
> `pip install --user --break-system-packages pandas numpy scikit-learn matplotlib seaborn statsmodels tabulate`

---

## 2. Workflow

```mermaid
flowchart TD
    A["Raw dataset + target + optional context/goal"] --> B{"--time-col provided?"}
    B -->|Yes| B1["Step0 Time series: split train/test strictly by time to prevent leakage"]
    B -->|No| B2["Step0 Cross-section: random train/test split"]
    B1 --> C["Step1 EDA: descriptive stats / missing rate / skew + charts"]
    B2 --> C
    C --> D["Step2 Preprocess: outlier clip -> impute (per-column strategy) -> encode -> scale<br/>fit on train only"]
    D --> E{"Feature construction mode"}
    E -->|custom| E1["User formula features"]
    E -->|auto| E2["Auto interactions/polynomials/time derivatives<br/>4 semantic gates: same-family/collinear/no-gain/over-cap"]
    E -->|both| E3["Stack both"]
    E1 --> F["Step4 Correlation analysis + heatmap"]
    E2 --> F
    E3 --> F
    F --> G["Step5 Remove redundancy: low-corr/high-corr/VIF with logged reasons"]
    G --> H["Step6 Feature selection: CV backward elimination by optimize-metric"]
    H --> I["Step7 Linear regression modeling<br/>skewed non-neg target auto log1p -> expm1 revert"]
    I --> J["Test-set evaluation WMAPE/MAE/RMSE/R2/AdjR2 + residual diagnostics"]
    J --> K["Outputs: report.md (ZH) + report_en.md (EN)<br/>+ PNG charts + processed_head50.csv + model.pkl"]
```

**The 7 steps at a glance**
- **Step 0** Split: time-series data is cut strictly in chronological order to stop future information from leaking into training.
- **Step 1** EDA: mean/variance/extremes/skew/missing-rate + target distribution or time-series plot.
- **Step 2** Preprocess: quantile outlier clipping → **columns are NOT dropped for high missingness**; instead a per-column imputation strategy (median/mean/mode/zero) is suggested from each column's distribution → One-Hot → standardization. All fit parameters come only from the training set.
- **Step 3** Feature construction: `auto` builds interactions/polynomials/time-derived features (interactions pass four gates — same-family, high-collinearity, no-gain, over-cap — with each skipped pair's reason logged); `custom` uses your business formulas; `both` stacks them.
- **Step 4** Correlation analysis + heatmap + feature-vs-target correlation bar chart.
- **Step 5** Redundancy removal: low correlation with target / high inter-feature correlation / VIF multicollinearity, each with a logged reason.
- **Step 6** Feature selection: guided by your chosen `--optimize-metric`, via cross-validated backward elimination on the training set.
- **Step 7** Modeling & evaluation: linear regression + test-set metrics (optimization target highlighted) + residual diagnostics; strongly right-skewed non-negative targets get an automatic log1p transform, reverted with expm1, and metrics are computed on the original scale.

---

## 3. Output (in `--outdir`)

| File | Content |
|---|---|
| **`report.md`** | Full **Chinese** report: context & goal, preprocessing summary, descriptive stats, correlations, redundancy-removal reasons, constructed-feature list, final features, model formula + coefficient table (with p-values / CIs), metrics, split description; **each chart carries a data-driven "chart notes" paragraph** |
| **`report_en.md`** | The **English** version of the above — identical structure (narrative and table headers translated; charts/formulas/numbers shared); both versions share the same set of images |
| `02_target.png` etc. PNGs | Charts with titles, labeled axes with meaning and units, large numbers auto-formatted as K/M/B; environments without a CJK font auto-fall back to English labels with no garbled boxes |
| `processed_head50.csv` | First 50 rows of the preprocessed data for inspection |
| `model.pkl` | Fitted model + scaler + feature list + preprocessing params for reuse/prediction |

---

## 4. Calling Prompt (concise template — state the essentials up front)

Copy the block below, fill in the bracketed fields, and send it to the assistant:

```
Please use the auto-feature-regression skill for feature engineering + linear regression.
- Data file: [path, e.g. ~/files/sales.csv]
- Target column: [e.g. daily_revenue]
- Time series?: [yes -> time column name, e.g. date; no -> leave blank]
- Columns to exclude: [IDs/names, e.g. id,shop_name; none -> blank]
- Context: [one line, e.g. daily e-commerce ops data with two-period revenue/price/volume]
- Goal: [one line, e.g. predict daily revenue and identify key drivers]
- Optimize metric: [WMAPE/MAE/RMSE/R2/Adj_R2, default WMAPE]
- Feature mode: [auto / custom (give formulas) / both; if custom, e.g. gmv_ratio = ads_gmv/(ecomm_gmv+1)]
Finally, give me the bilingual report and the visualization charts.
```

**Minimal example (time series)**

```
Use the auto-feature-regression skill: data ~/files/sales.csv, target daily_revenue,
time column date, exclude id; context is daily e-commerce ops data, goal is to predict
daily revenue and find key drivers, optimize by WMAPE.
```
