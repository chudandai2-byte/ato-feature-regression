# auto-feature-regression 使用说明（中文版）

> 面向**回归预测任务**的一站式自动化特征工程 + 线性回归建模 skill。喂入一份原始数据集，产出：预处理/特征工程/建模/评估的**中英双语报告** + 可视化图表 + 可复用模型。

---

## 一、Input（输入）

### 1. 必备输入

| 项 | 说明 |
|---|---|
| **数据集文件** | CSV / Excel / Parquet，含 1 个数值型预测目标列 + 若干特征列。CSV 自动探测编码（utf-8/gbk/latin-1） |
| **目标字段名** (`--target`) | 要预测的数值列名 |

### 2. 关键可选输入

| 参数 | 何时用 | 示例 |
|---|---|---|
| `--time-col` | **时间序列数据必传**，否则退化为随机划分导致评估失真 | `--time-col date` |
| `--exclude` | 排除 ID/名称等非特征列、或易泄漏的 target 衍生列 | `--exclude id,shop_name` |
| `--context` | 一句话说明数据业务背景，写入报告并让图解更贴切 | `--context "电商日度经营数据"` |
| `--goal` | 一句话说明本次建模目标，让图解围绕目标展开 | `--goal "预测日营收并找关键驱动因子"` |
| `--optimize-metric` | 指定优化指标，驱动特征选择方向 | `WMAPE`(默认)/`MAE`/`RMSE`/`R2`/`Adj_R2` |
| `--feature-mode` | 特征构造模式 | `auto`(默认)/`custom`/`both` |
| `--custom-features` | 自定义业务特征公式 | `"gmv_ratio = ads_gmv/(ecomm_gmv+1)"` |
| `--interaction-pairs` | 你清楚哪些特征相乘有业务含义时，精确指定 | `"price*volume; ad_cost*ctr"` |
| `--impute` / `--impute-overrides` | 缺失值填充策略（全局 / 按列） | `--impute-overrides "recharge:zero"` |
| `--log-target` | 严重右偏目标的 log1p 变换开关 | `auto`(默认)/`on`/`off` |
| `--outdir` | 输出目录 | `--outdir ./output` |

> 完整参数见 `SKILL.md`。首次使用需安装依赖：
> `pip install --user --break-system-packages pandas numpy scikit-learn matplotlib seaborn statsmodels tabulate`

---

## 二、Workflow（工作流）

```mermaid
flowchart TD
    A["输入原始数据集 + target + 可选 context/goal"] --> B{"是否提供 --time-col?"}
    B -->|是| B1["Step0 时间序列: 严格按时间升序划分 train/test 防泄漏"]
    B -->|否| B2["Step0 普通数据: 随机划分 train/test"]
    B1 --> C["Step1 EDA: 描述统计/缺失率/偏度 + 可视化"]
    B2 --> C
    C --> D["Step2 预处理: 离群截断→缺失填充(按列建议策略)→类别编码→标准化<br/>参数仅在训练集 fit"]
    D --> E{"特征构造模式"}
    E -->|custom| E1["用户公式特征"]
    E -->|auto| E2["自动交互/多项式/时序衍生<br/>4道语义护栏: 同族/高共线/无增益/超上限"]
    E -->|both| E3["两者叠加"]
    E1 --> F["Step4 相关性分析 + 热力图"]
    E2 --> F
    E3 --> F
    F --> G["Step5 去冗余: 低相关/高相关/VIF 逐条记录原因"]
    G --> H["Step6 特征选择: 按优化指标做 CV 后向剔除"]
    H --> I["Step7 线性回归建模<br/>右偏非负目标自动 log1p→expm1 还原"]
    I --> J["测试集评估 WMAPE/MAE/RMSE/R²/AdjR² + 残差诊断"]
    J --> K["产出: report.md(中) + report_en.md(英)<br/>+ PNG 图表 + processed_head50.csv + model.pkl"]
```

**7 步要点**
- **Step 0** 数据划分：时间序列严格按时间顺序切分，防止未来信息泄漏到训练集。
- **Step 1** EDA：均值/方差/极值/偏度/缺失率 + 目标分布或时序图。
- **Step 2** 预处理：离群分位截断 → **不因高缺失率删列**，而是按每列分布建议填充策略（中位数/均值/众数/填0）→ One-Hot → 标准化。所有 fit 参数只取自训练集。
- **Step 3** 特征构造：`auto` 自动造交互/多项式/时序衍生（交互项经同族、高共线、无增益、数量上限四道过滤，被跳过的组合逐条记录原因）；`custom` 用你给的业务公式；`both` 叠加。
- **Step 4** 相关性分析 + 热力图 + 特征-目标相关性条形图。
- **Step 5** 去冗余：与 target 低相关 / 特征间高相关 / VIF 多重共线性，逐条记录删除原因。
- **Step 6** 特征选择：以你选定的 `--optimize-metric` 为准，在训练集上交叉验证后向剔除。
- **Step 7** 建模评估：线性回归 + 测试集指标（高亮优化目标）+ 残差诊断；严重右偏非负目标自动 log1p 变换、预测后 expm1 还原，指标在原始尺度计算。

---

## 三、Output（产物，位于 `--outdir`）

| 文件 | 内容 |
|---|---|
| **`report.md`** | 完整中文报告：分析背景目标、预处理汇总、描述统计、相关性、去冗余原因、构造特征清单、最终特征、模型公式+系数表(含 p 值/置信区间)、评价指标、数据划分说明；**每张图配数据驱动的「图解」** |
| **`report_en.md`** | 上述报告的**英文版**，结构完全一致（叙述与表头翻译为英文，图表/公式/数值共用），两版共享同一批图 |
| `02_target.png` 等 PNG | 可视化图表：标题/横纵坐标含义/单位均标注，大数值自动 K/M/B 格式化；无中文字体环境自动降级为英文标签、绝不乱码 |
| `processed_head50.csv` | 预处理后数据前 50 行，便于核对 |
| `model.pkl` | 拟合好的模型 + scaler + 特征列表 + 预处理参数，供后续复用/预测 |

---

## 四、调用 Prompt（简洁模板，调用时即说清必要信息）

复制下面这段，把方括号内替换成你的信息后发给助手即可：

```
请用 auto-feature-regression skill 帮我做特征工程 + 线性回归建模。
- 数据文件：[数据集路径，如 ~/files/sales.csv]
- 预测目标列：[target 列名，如 daily_revenue]
- 是否时间序列：[是→时间列名，如 date；否→不填]
- 需排除的列：[ID/名称等，如 id,shop_name；无则不填]
- 分析背景：[一句话，如 电商日度经营数据，含两期收入/价格/销量]
- 分析目标：[一句话，如 预测日营收并识别关键驱动因子]
- 优化指标：[WMAPE/MAE/RMSE/R2/Adj_R2，默认 WMAPE]
- 特征构造：[auto 自动 / custom 我给公式 / both；给公式时附上，如 gmv_ratio = ads_gmv/(ecomm_gmv+1)]
最后请给我中英双语报告和可视化图表。
```

**最小示例（时间序列）**

```
请用 auto-feature-regression skill 建模：数据 ~/files/sales.csv，目标列 daily_revenue，
时间列 date，排除 id；背景是电商日度经营数据，目标是预测日营收并找关键驱动因子，优化指标用 WMAPE。
```
