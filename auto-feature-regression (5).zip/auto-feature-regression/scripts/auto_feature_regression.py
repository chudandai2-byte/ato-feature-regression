#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动化特征工程 + 线性回归 skill (v1, 可迭代版)
================================================
覆盖 workflow:
  Step 0  数据划分策略判定 (时间序列 -> 严格按时间顺序划分; 否则随机划分), 防数据泄漏
  Step 1  原始数据 EDA
  Step 2  特征预处理 (离群截断 -> 缺失处理 -> 类别编码 -> 标准化), 参数只在训练集 fit
  Step 3  特征构造 (交互项 / 多项式 / 时间序列衍生), 全部登记
  Step 4  相关性分析 + 热力图
  Step 5  去除冗余特征 (高相关 / VIF / 与target低相关), 记录原因
  Step 6  特征选择 (相关性+VIF 阈值, 可换 Lasso/逐步回归)
  Step 7  线性回归建模 + 测试集评估 (WMAPE/MAE/RMSE/R2/AdjR2) + 残差诊断

用法:
  python3 auto_feature_regression.py \
      --data your.csv --target 目标字段名 \
      --time-col 时间字段名 \
      --exclude id,order_no \
      --outdir ./output
  说明: --time-col 有则视为时间序列(无则随机划分); --exclude 为需排除的非特征列(逗号分隔)

产物: outdir/ 下的图表 + report.md + processed_head50.csv + model.pkl
"""

import os
import sys
import json
import argparse
import warnings
import pickle
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

# ---------------- 中文字体: 真实探测 + 显式绑定 + 自动降级 ----------------
# 目标: 保证在任何环境下图表都不出现方框。
#   1) 从常见路径/字体库真实定位一个含中文字形的字体文件;
#   2) 用 FontProperties 显式绑定文件路径(比只设 rcParams 更稳, 不依赖全局查找);
#   3) 若探测不到任何中文字体, ZH_OK=False, 所有标签自动降级为英文。
import matplotlib.font_manager as _fm
from matplotlib.font_manager import FontProperties as _FP

def _locate_cjk_font():
    # (a) 优先扫描常见字体文件路径
    _cand_paths = [
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/truetype/arphic/uming.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Medium.ttc",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/simhei.ttf",
    ]
    for p in _cand_paths:
        if os.path.isfile(p):
            return p
    # (b) 再按字体名从 matplotlib 字体库查找文件路径
    for _name in ["Noto Sans CJK SC", "Noto Sans CJK JP", "WenQuanYi Zen Hei",
                  "WenQuanYi Micro Hei", "Source Han Sans SC", "Microsoft YaHei",
                  "PingFang SC", "SimHei", "Droid Sans Fallback"]:
        try:
            _path = _fm.findfont(_FP(family=_name), fallback_to_default=False)
            if _path and os.path.isfile(_path):
                return _path
        except Exception:
            continue
    return None

_CJK_PATH = _locate_cjk_font()
if _CJK_PATH:
    try:
        _fm.fontManager.addfont(_CJK_PATH)
        ZH_FP = _FP(fname=_CJK_PATH)
        matplotlib.rcParams["font.sans-serif"] = [ZH_FP.get_name()] + \
            matplotlib.rcParams.get("font.sans-serif", [])
        ZH_OK = True
    except Exception:
        ZH_FP, ZH_OK = None, False
else:
    ZH_FP, ZH_OK = None, False
matplotlib.rcParams["axes.unicode_minus"] = False

# 双语标签工具: ZH_OK 时用中文, 否则自动用英文, 保证任何环境都可读
def L(zh, en):
    """label: 有中文字体返回中文, 否则返回英文, 确保图表标签永不乱码。"""
    return zh if ZH_OK else en

# 大数值坐标轴格式化 (避免只显示 1e7 让人困惑, 改成 千/百万/十亿 可读单位)
from matplotlib.ticker import FuncFormatter as _FuncFormatter
def _human_fmt(x, _pos=None):
    ax = abs(x)
    if ax >= 1e9:  return f"{x/1e9:.1f}B"
    if ax >= 1e6:  return f"{x/1e6:.1f}M"
    if ax >= 1e3:  return f"{x/1e3:.1f}K"
    if ax == int(ax): return f"{int(x)}"
    return f"{x:.2f}"
HUMAN_FMT = _FuncFormatter(_human_fmt)


from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm


# ----------------------------- 配置 -----------------------------
class Config:
    TEST_SIZE = 0.2            # 测试集比例
    CLIP_LOW, CLIP_HIGH = 0.01, 0.99   # 离群截断分位数
    CORR_HIGH = 0.9           # 特征间高相关阈值
    CORR_TARGET_MIN = 0.03    # 与 target 相关性最低阈值 (低于则候选剔除)
    VIF_THRESH = 10.0         # VIF 多重共线性阈值
    MAKE_INTERACTIONS = True  # 是否构造交互项
    MAKE_POLY = True          # 是否构造多项式(平方)项
    MAX_BASE_FOR_CONSTRUCT = 6  # 参与构造的基础特征上限(与target相关性最高的前N个), 防维度爆炸
    SKEW_LOG_THRESH = 1.0     # 偏度绝对值超过该阈值且非负的特征/目标, 建议 log1p 变换
    HIGH_MISS_HINT = 0.5      # 缺失率超过该值仅作提示(不再自动删列)
    # ---- 自动交互项语义护栏 (解决"同类特征被盲目相乘、无业务含义"问题) ----
    INTER_SKIP_SAME_FAMILY = True  # 跳过"同族"特征相乘(如 revenue_q1 × revenue_q2, 无业务含义)
    INTER_SKIP_HIGH_CORR = 0.8     # 两母特征相关系数 > 此值则不相乘(相乘只会加剧共线性)
    INTER_MIN_GAIN = 0.02          # 交互项与target的|corr|须比两母特征各自|corr|至少高出此值, 否则丢弃(无增益)
    INTER_MAX_KEEP = 8             # 按增益排序后自动交互项最多保留数量, 防维度爆炸


# 支持的模型优化目标指标 -> (显示名, 是否越小越好)
METRIC_REGISTRY = {
    "WMAPE": ("WMAPE", True),
    "MAE":   ("MAE",   True),
    "RMSE":  ("RMSE",  True),
    "R2":    ("R2",    False),
    "Adj_R2": ("Adj_R2", False),
}


REPORT = []     # 中文报告文本
REPORT_EN = []  # 英文报告文本


def log(msg="", en=None):
    """收集报告文本。
    msg: 中文(或语言无关的表格/数据)内容, 写入中文报告;
    en : 对应英文内容; 省略时英文报告复用 msg(适用于表格/公式/图片等语言无关内容)。
    print 仅输出中文, 便于运行时观察。
    """
    print(msg)
    REPORT.append(str(msg))
    REPORT_EN.append(str(msg if en is None else en))


# ----------------------------- 工具 -----------------------------
def wmape(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    denom = np.sum(np.abs(y_true))
    return np.sum(np.abs(y_true - y_pred)) / denom if denom != 0 else np.nan


def mae(y_true, y_pred):
    return float(np.mean(np.abs(np.asarray(y_true) - np.asarray(y_pred))))


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((np.asarray(y_true) - np.asarray(y_pred)) ** 2)))


def r2_score_(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=float)
    y_pred = np.asarray(y_pred, dtype=float)
    ss_res = np.sum((y_true - y_pred) ** 2)
    ss_tot = np.sum((y_true - np.mean(y_true)) ** 2)
    return 1 - ss_res / ss_tot if ss_tot != 0 else np.nan


def adjusted_r2(r2, n, p):
    if n - p - 1 <= 0:
        return np.nan
    return 1 - (1 - r2) * (n - 1) / (n - p - 1)


def load_data(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in [".xlsx", ".xls"]:
        return pd.read_excel(path)
    if ext == ".parquet":
        return pd.read_parquet(path)
    # csv: 尝试自动编码
    for enc in ["utf-8", "gbk", "latin-1"]:
        try:
            return pd.read_csv(path, encoding=enc)
        except Exception:
            continue
    return pd.read_csv(path)


def feature_family(col):
    """提取特征词根用于'同族'判定: 去掉尾部的季度/期号/年份/序号等后缀。
    revenue_q1 / revenue_q2 -> revenue; sales_2023 / sales_2024 -> sales;
    x1 / x2 -> x; cost_m1 -> cost。目的: 识别'同一指标的不同期/不同分片',
    这类特征相乘通常无业务含义且高度共线。"""
    import re
    s = str(col).lower()
    # 去掉常见的期号/序号后缀: _q1 _q2 _m1 _h1 _2023 _t1 或结尾纯数字
    s = re.sub(r'(_?(q|m|h|w|d|y|t|fy)?\d+)$', '', s)
    s = re.sub(r'(_(year|month|quarter|week|day|period)_?\d*)$', '', s)
    return s if s else str(col).lower()


def parse_interaction_pairs(spec):
    """解析手动交互对 'a*b; c*d' -> [(a,b),(c,d)]"""
    out = []
    if not spec:
        return out
    for p in [x.strip() for x in spec.split(";") if x.strip()]:
        if "*" not in p:
            raise ValueError(f"交互对格式错误(缺少'*'): {p}")
        a, b = p.split("*", 1)
        out.append((a.strip(), b.strip()))
    return out


def parse_custom_features(spec):
    """解析自定义特征规格 -> [(新特征名, 表达式字符串), ...]
    spec 可为: (1) 字符串, 多条用 ; 分隔; (2) .txt 文件路径, 每行一条。
    每条格式: '新特征名 = pandas表达式'
    """
    if not spec:
        return []
    text = spec
    if os.path.isfile(spec):
        with open(spec, "r", encoding="utf-8") as f:
            text = f.read()
        parts = [ln.strip() for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    else:
        parts = [p.strip() for p in text.split(";") if p.strip()]
    out = []
    for p in parts:
        if "=" not in p:
            raise ValueError(f"自定义特征格式错误(缺少'='): {p}")
        name, expr = p.split("=", 1)
        out.append((name.strip(), expr.strip()))
    return out


def parse_impute_overrides(spec):
    """解析按列填充策略覆盖 -> {列名: 策略}。格式 '列名:策略; 列名:策略'"""
    out = {}
    if not spec:
        return out
    for p in [x.strip() for x in spec.split(";") if x.strip()]:
        if ":" not in p:
            raise ValueError(f"impute-overrides 格式错误(缺少':'): {p}")
        col, strat = p.split(":", 1)
        strat = strat.strip().lower()
        if strat not in {"median", "mean", "mode", "zero"}:
            raise ValueError(f"不支持的填充策略: {strat} (列 {col.strip()})")
        out[col.strip()] = strat
    return out


def suggest_impute_strategy(series, col_name):
    """基于数据特征探索, 为单列给出缺失值填充策略建议 + 原因。
    返回 (策略, 原因_zh, 原因_en)。策略 ∈ {median, mean, mode, zero}"""
    miss_rate = series.isna().mean()
    non_na = series.dropna()
    nunique = non_na.nunique()
    # 疑似计数/金额型(非负、含较多0)且缺失可能代表"无发生" -> 填0
    if len(non_na) > 0:
        nonneg = (non_na >= 0).all()
        zero_ratio = (non_na == 0).mean()
        skew = non_na.skew() if len(non_na) > 2 else 0.0
    else:
        nonneg, zero_ratio, skew = False, 0.0, 0.0

    if nunique <= 10 and not pd.api.types.is_float_dtype(series):
        return ("mode", f"离散/低基数列(唯一值{nunique}个), 用众数填充",
                f"discrete/low-cardinality column ({nunique} unique values), fill with mode")
    if nonneg and zero_ratio > 0.3:
        return ("zero", f"非负且已有{zero_ratio:.0%}为0(疑似计数/金额型, 缺失多代表未发生), 填0",
                f"non-negative with {zero_ratio:.0%} already zero (count/amount-like, missing likely means not occurred), fill 0")
    if abs(skew) > 1.0:
        return ("median", f"分布偏斜(skew={skew:.2f}), 用中位数更稳健(抗离群)",
                f"skewed distribution (skew={skew:.2f}), median is more robust (outlier-resistant)")
    return ("mean", f"近似对称分布(skew={skew:.2f}), 用均值填充",
            f"approximately symmetric (skew={skew:.2f}), fill with mean")


def compute_fill_value(series, strategy):
    if strategy == "median":
        return series.median()
    if strategy == "mean":
        return series.mean()
    if strategy == "mode":
        m = series.mode()
        return m.iloc[0] if len(m) else 0
    if strategy == "zero":
        return 0
    raise ValueError(strategy)


def _ctx_prefix(context, goal):
    """把用户给的分析背景/目标拼成一句引导语(中/英), 供图表解读复用。返回 (zh, en)。"""
    zh_bits, en_bits = [], []
    if context:
        zh_bits.append(f"结合分析背景「{context}」")
        en_bits.append(f"in the context of “{context}”")
    if goal:
        zh_bits.append(f"围绕分析目标「{goal}」")
        en_bits.append(f"toward the goal “{goal}”")
    zh = ("，".join(zh_bits) + "，") if zh_bits else ""
    en = (", ".join(en_bits) + ", ") if en_bits else ""
    return zh, en


def explain_chart(kind, context="", goal="", **facts):
    """结合分析目标 + 数据事实, 为一张图生成一段解读文字(数据驱动, 非套话)。
    kind ∈ {target_ts, target_dist, missing, heatmap, residual}
    facts 里传入该图对应的真实统计量。返回 (中文解读, 英文解读)。"""
    pz, pe = _ctx_prefix(context, goal)
    if kind == "target_ts":
        zh = (f"> **图解**：{pz}该图展示目标 `{facts.get('target')}` 随时间的变化。"
              f"训练区间均值约 {facts.get('mean')}，最大 {facts.get('mx')}、最小 {facts.get('mn')}；"
              f"整体偏度 {facts.get('skew')}（>1 为明显右偏，少数高峰主导量级）。"
              f"若曲线呈周期性尖峰，通常是季度/月度结算节奏，建模时的时序衍生特征(lag/rolling)正是为捕捉此规律。\n")
        en = (f"> **Chart notes**: {pe}this chart shows the target `{facts.get('target')}` over time. "
              f"Training-period mean is about {facts.get('mean')}, max {facts.get('mx')}, min {facts.get('mn')}; "
              f"overall skewness {facts.get('skew')} (>1 means clearly right-skewed, a few peaks dominate the magnitude). "
              f"Periodic spikes usually reflect a quarterly/monthly settlement rhythm — the time-series derived features (lag/rolling) are built precisely to capture this pattern.\n")
        return zh, en
    if kind == "target_dist":
        zh = (f"> **图解**：{pz}该图为目标 `{facts.get('target')}` 的分布直方图(纵轴=样本频数)。"
              f"均值 {facts.get('mean')}、中位数 {facts.get('median')}，偏度 {facts.get('skew')}。"
              f"{'分布明显右偏，已对目标做 log1p 变换后再建模、预测时 expm1 还原,使线性回归不被极端大值主导。' if facts.get('logged') else '分布较对称,未做 log 变换。'}\n")
        en = (f"> **Chart notes**: {pe}this is the distribution histogram of the target `{facts.get('target')}` (y-axis = sample count). "
              f"Mean {facts.get('mean')}, median {facts.get('median')}, skewness {facts.get('skew')}. "
              f"{'The distribution is clearly right-skewed, so a log1p transform is applied to the target before modeling and reverted with expm1 at prediction, preventing extreme large values from dominating the linear regression.' if facts.get('logged') else 'The distribution is fairly symmetric, so no log transform is applied.'}\n")
        return zh, en
    if kind == "missing":
        top = facts.get("top_missing")
        top_en = facts.get("top_missing_en")
        zh = (f"> **图解**：{pz}该图为各特征缺失率(横轴=缺失样本占比)。"
              f"{'缺失最严重的是 '+top+'；' if top else ''}"
              f"本 skill 不因高缺失率删列，而是按每列分布给出填充策略(见 Step 2)，避免丢失高缺失但可能强信号的字段。\n")
        en = (f"> **Chart notes**: {pe}this chart shows the missing rate per feature (x-axis = fraction of missing rows). "
              f"{'The most-missing feature is '+(top_en or top)+'; ' if top else ''}"
              f"this skill does NOT drop columns for high missingness; instead it assigns a per-column imputation strategy (see Step 2), avoiding the loss of high-missing but potentially strong-signal fields.\n")
        return zh, en
    if kind == "heatmap":
        zh = (f"> **图解**：{pz}该图为特征间及特征-目标的皮尔逊相关系数矩阵(红=正相关、蓝=负相关、深浅表强弱)。"
              f"与目标 `{facts.get('target')}` 相关性最高的是 {facts.get('top_corr')}。"
              f"特征间深色块表示高度共线，是 Step 5 按相关性/VIF 去冗余的依据。\n")
        en = (f"> **Chart notes**: {pe}this is the Pearson correlation matrix among features and between features and the target "
              f"(red = positive, blue = negative, shade = strength). "
              f"The features most correlated with the target `{facts.get('target')}` are {facts.get('top_corr')}. "
              f"Dark blocks between features indicate high collinearity — the basis for redundancy removal by correlation/VIF in Step 5.\n")
        return zh, en
    if kind == "residual":
        zh = (f"> **图解**：{pz}左图残差 vs 拟合值应随机散布在 0 线两侧、无喇叭形；"
              f"右图 Q-Q 点贴红线说明残差近似正态。"
              f"{'当前残差在大预测值区呈发散(异方差)迹象，说明极端大值仍偏难拟合，可考虑进一步变换或分段建模。' if facts.get('heterosced') else '残差形态大体符合线性回归假设。'}\n")
        en = (f"> **Chart notes**: {pe}in the left panel, residuals vs fitted values should scatter randomly around the 0 line with no funnel shape; "
              f"in the right panel, Q-Q points lying on the red line indicate residuals are approximately normal. "
              f"{'The residuals currently show a fanning-out (heteroscedasticity) trend at large predicted values, meaning extreme large values are still hard to fit — consider a further transform or piecewise modeling.' if facts.get('heterosced') else 'The residual pattern broadly satisfies the linear-regression assumptions.'}\n")
        return zh, en
    return "", ""



# ============================================================
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="数据集路径")
    ap.add_argument("--target", required=True, help="预测目标字段名")
    ap.add_argument("--time-col", default=None, help="时间字段名; 提供则按时间序列严格划分")
    ap.add_argument("--exclude", default="", help="排除列(逗号分隔), 如 id,order_no")
    ap.add_argument("--outdir", default="./output", help="输出目录")
    ap.add_argument("--feature-mode", default="auto",
                    choices=["auto", "custom", "both"],
                    help="特征构造模式: auto=自动交互/多项式; custom=仅用户自定义公式; both=两者叠加")
    ap.add_argument("--custom-features", default="",
                    help="自定义特征, 每条形如 '新特征名 = pandas表达式', 多条用 ; 分隔。"
                         "如 'gmv_ratio = shop_ads_gmv / (shop_ecomm_gmv + 1); cost_sq = quarter_cost ** 2'。"
                         "也可传一个 .txt 文件路径, 每行一条。")
    ap.add_argument("--optimize-metric", default="WMAPE",
                    choices=list(METRIC_REGISTRY.keys()),
                    help="模型优化目标指标, 用于特征选择方向与最优模型判定: WMAPE/MAE/RMSE/R2/Adj_R2")
    ap.add_argument("--impute", default="auto",
                    choices=["auto", "median", "mean", "mode", "zero"],
                    help="缺失值填充策略: auto=基于数据探索自动为每列选择(默认); "
                         "median/mean/mode/zero=对所有数值列统一使用该策略")
    ap.add_argument("--impute-overrides", default="",
                    help="按列指定填充策略, 覆盖 auto/全局设置。格式 '列名:策略', 多条用 ; 分隔, "
                         "策略∈{median,mean,mode,zero}。如 'recharge_amount:zero; shop_num:median'")
    ap.add_argument("--log-target", default="auto",
                    choices=["auto", "on", "off"],
                    help="对严重右偏的目标做 log1p 变换、预测后 expm1 还原(评估在原始尺度): "
                         "auto=偏度超阈值且非负时自动开启(默认); on=强制开启; off=关闭")
    ap.add_argument("--interaction-pairs", default="",
                    help="手动指定自动交互项只在这些特征对之间构造, 格式 'a*b; c*d', 多对用 ; 分隔。"
                         "指定后将跳过自动两两组合, 只造你列出的对(仍受增益校验)。"
                         "适合你清楚哪些特征相乘有业务含义时。")
    ap.add_argument("--allow-same-family", action="store_true",
                    help="允许对'同族'特征(如 revenue_q1 × revenue_q2, 词根相同)也构造交互项; "
                         "默认关闭, 因为同类特征相乘通常无业务含义且加剧共线性。")
    ap.add_argument("--context", default="",
                    help="分析背景: 数据来自什么业务/场景、各字段的业务含义等。"
                         "用于在报告里结合业务对每张图给出更贴切的解读。")
    ap.add_argument("--goal", default="",
                    help="分析目标: 你想通过这次建模回答什么问题、关注哪些因素。"
                         "用于让图表解读文字围绕你的目标展开。")
    args = ap.parse_args()

    assert args.optimize_metric in METRIC_REGISTRY, f"不支持的优化指标: {args.optimize_metric}"
    opt_metric = args.optimize_metric
    opt_lower_better = METRIC_REGISTRY[opt_metric][1]

    cfg = Config()
    os.makedirs(args.outdir, exist_ok=True)

    def savefig(name):
        p = os.path.join(args.outdir, name)
        plt.tight_layout(); plt.savefig(p, dpi=120, bbox_inches="tight"); plt.close()
        return p

    # ---------- 读取 ----------
    df = load_data(args.data)
    log("# 自动化特征工程 + 线性回归 报告\n", "# Automated Feature Engineering + Linear Regression Report\n")
    log(f"数据集: `{args.data}`  形状: {df.shape[0]} 行 × {df.shape[1]} 列\n",
        f"Dataset: `{args.data}`  Shape: {df.shape[0]} rows × {df.shape[1]} cols\n")
    if args.context or args.goal:
        log("## 分析背景与目标\n", "## Analysis Context & Goal\n")
        if args.context:
            log(f"- **分析背景**：{args.context}", f"- **Context**: {args.context}")
        if args.goal:
            log(f"- **分析目标**：{args.goal}", f"- **Goal**: {args.goal}")
        log("\n(下文每张图均结合上述背景/目标给出解读。)\n",
            "\n(Every chart below is interpreted in light of the context/goal above.)\n")

    target = args.target
    time_col = args.time_col
    exclude = [c.strip() for c in args.exclude.split(",") if c.strip()]
    assert target in df.columns, f"target 字段 '{target}' 不在数据集中. 现有列: {list(df.columns)}"

    # ============ Step 0 数据划分策略 ============
    log("## Step 0 · 数据划分策略\n", "## Step 0 · Data Split Strategy\n")
    is_ts = time_col is not None and time_col in df.columns
    if is_ts:
        df[time_col] = pd.to_datetime(df[time_col], errors="coerce")
        df = df.sort_values(time_col).reset_index(drop=True)  # 严格按时间升序
        split_idx = int(len(df) * (1 - cfg.TEST_SIZE))
        train_df = df.iloc[:split_idx].copy()
        test_df = df.iloc[split_idx:].copy()
        log(f"- 检测到时间列 `{time_col}` → **时间序列数据集, 严格按时间顺序划分(不打乱)**",
            f"- Detected time column `{time_col}` → **time-series dataset, split strictly in chronological order (no shuffle)**")
        log(f"- 训练集时间区间: {train_df[time_col].min()} ~ {train_df[time_col].max()} ({len(train_df)} 行)",
            f"- Train time range: {train_df[time_col].min()} ~ {train_df[time_col].max()} ({len(train_df)} rows)")
        log(f"- 测试集时间区间: {test_df[time_col].min()} ~ {test_df[time_col].max()} ({len(test_df)} 行)\n",
            f"- Test time range: {test_df[time_col].min()} ~ {test_df[time_col].max()} ({len(test_df)} rows)\n")
    else:
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
        split_idx = int(len(df) * (1 - cfg.TEST_SIZE))
        train_df = df.iloc[:split_idx].copy()
        test_df = df.iloc[split_idx:].copy()
        log(f"- 未提供时间列 → **非时间序列, 随机划分** (train {len(train_df)} / test {len(test_df)})\n",
            f"- No time column provided → **non-time-series, random split** (train {len(train_df)} / test {len(test_df)})\n")

    # 候选特征列 = 全部 - target - time_col - exclude
    drop_cols = set([target] + exclude + ([time_col] if time_col else []))
    feat_cols = [c for c in df.columns if c not in drop_cols]
    num_cols = [c for c in feat_cols if pd.api.types.is_numeric_dtype(df[c])]
    cat_cols = [c for c in feat_cols if c not in num_cols]

    # ============ Step 1 EDA ============
    log("## Step 1 · 原始数据 EDA\n", "## Step 1 · Raw Data EDA\n")
    desc = train_df[num_cols + [target]].describe().T
    desc["missing_rate"] = train_df[num_cols + [target]].isna().mean()
    desc["skew"] = train_df[num_cols + [target]].skew()
    log("数值特征描述性统计(基于训练集):\n", "Descriptive statistics of numeric features (on training set):\n")
    log(desc.round(4).to_markdown() + "\n")
    if cat_cols:
        log(f"类别特征: {cat_cols} (将做 One-Hot 编码)\n",
            f"Categorical features: {cat_cols} (will be One-Hot encoded)\n")

    # 缺失率图
    miss = train_df[feat_cols].isna().mean().sort_values(ascending=False)
    if miss.max() > 0:
        fig, ax = plt.subplots(figsize=(8, max(3, 0.3 * len(miss))))
        miss[miss > 0].plot(kind="barh", ax=ax)
        ax.set_title(L("各特征缺失值率", "Missing Rate per Feature"), fontproperties=ZH_FP)
        ax.set_xlabel(L("缺失率(占样本比例)", "Missing rate (fraction of rows)"), fontproperties=ZH_FP)
        ax.set_ylabel(L("特征", "Feature"), fontproperties=ZH_FP)
        ax.xaxis.set_major_formatter(plt.FuncFormatter(lambda v, p: f"{v:.0%}"))
        for lab in ax.get_yticklabels():
            lab.set_fontproperties(ZH_FP)
        savefig("01_missing_rate.png")
        log("![missing](01_missing_rate.png)\n")
        _mz, _me = explain_chart("missing", args.context, args.goal,
                                 top_missing=f"`{miss.index[0]}`（{miss.iloc[0]:.0%}）" if miss.iloc[0] > 0 else "",
                                 top_missing_en=f"`{miss.index[0]}` ({miss.iloc[0]:.0%})" if miss.iloc[0] > 0 else "")
        log(_mz, _me)
    # target 分布 / 趋势
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    if is_ts:
        ax.plot(train_df[time_col], train_df[target])
        ax.set_title(L(f"{target} 随时间变化(训练集)", f"{target} over time (train)"), fontproperties=ZH_FP)
        ax.set_xlabel(L("时间", "Time"), fontproperties=ZH_FP)
        ax.set_ylabel(L(f"{target}(目标值)", f"{target} (target)"), fontproperties=ZH_FP)
        fig.autofmt_xdate()
    else:
        sns.histplot(train_df[target].dropna(), kde=True, ax=ax)
        ax.set_title(L(f"{target} 分布", f"{target} distribution"), fontproperties=ZH_FP)
        ax.set_xlabel(L(f"{target}(目标值)", f"{target} (target)"), fontproperties=ZH_FP)
        ax.set_ylabel(L("频数", "Count"), fontproperties=ZH_FP)
    ax.yaxis.set_major_formatter(HUMAN_FMT)
    savefig("02_target.png")
    log("![target](02_target.png)\n")

    # ---- 目标变量 log 变换判定 (针对收入等严重右偏、非负的目标) ----
    tgt_skew = train_df[target].dropna().skew()
    tgt_min = train_df[target].min()
    if args.log_target == "on":
        use_log = True
    elif args.log_target == "off":
        use_log = False
    else:  # auto
        use_log = (tgt_skew > cfg.SKEW_LOG_THRESH) and (tgt_min >= 0)
    if use_log and tgt_min < 0:
        log(f"⚠️ 目标含负值(min={tgt_min:.4g}), 无法 log1p 变换, 已关闭 log。\n",
            f"⚠️ Target contains negative values (min={tgt_min:.4g}); log1p is not applicable, log disabled.\n")
        use_log = False
    log("### 目标变量分布诊断与变换\n", "### Target Distribution Diagnosis & Transform\n")
    log(f"- 目标 `{target}` 偏度 skew = **{tgt_skew:.3f}**, 最小值 = {tgt_min:.4g}",
        f"- Target `{target}` skewness = **{tgt_skew:.3f}**, min = {tgt_min:.4g}")
    if use_log:
        log(f"- 判定: 严重右偏(skew>{cfg.SKEW_LOG_THRESH})且非负 → **对目标做 log1p 变换**, "
            f"预测后用 expm1 还原, **所有评价指标在原始尺度上计算**。\n",
            f"- Decision: strongly right-skewed (skew>{cfg.SKEW_LOG_THRESH}) and non-negative → **apply log1p to the target**, "
            f"revert with expm1 after prediction; **all metrics are computed on the original scale**.\n")
    else:
        log(f"- 判定: 无需 log 变换(偏度未超阈值 / 已关闭 / 含负值)。\n",
            f"- Decision: no log transform (skew below threshold / disabled / contains negatives).\n")

    # 目标图(02_target.png)的解读文字: 此时已知 skew / use_log 等事实
    _t = train_df[target].dropna()
    if is_ts:
        _cz, _ce = explain_chart("target_ts", args.context, args.goal, target=target,
                                 mean=f"{_human_fmt(_t.mean())}", mx=f"{_human_fmt(_t.max())}",
                                 mn=f"{_human_fmt(_t.min())}", skew=f"{tgt_skew:.2f}")
        log(_cz, _ce)
    else:
        _cz, _ce = explain_chart("target_dist", args.context, args.goal, target=target,
                                 mean=f"{_human_fmt(_t.mean())}", median=f"{_human_fmt(_t.median())}",
                                 skew=f"{tgt_skew:.2f}", logged=use_log)
        log(_cz, _ce)

    # 目标变换 / 还原函数: 建模用变换后的 y, 预测结果还原到原始尺度后再评估
    def y_fwd(y):
        return np.log1p(y) if use_log else np.asarray(y, dtype=float)

    def y_inv(y):
        return np.expm1(y) if use_log else np.asarray(y, dtype=float)

    # ============ Step 2 预处理 (fit on train) ============
    log("## Step 2 · 特征预处理 (顺序: 离群截断 → 缺失填充 → 编码 → 标准化)\n",
        "## Step 2 · Feature Preprocessing (order: outlier clip → impute → encode → scale)\n")
    prep_log = []

    # 2a 缺失情况探索 (不再自动删列, 仅对高缺失列作提示)
    impute_overrides = parse_impute_overrides(args.impute_overrides)
    high_miss = [c for c in num_cols if train_df[c].isna().mean() > cfg.HIGH_MISS_HINT]
    if high_miss:
        log(f"⚠️ 高缺失列提示(缺失率>{cfg.HIGH_MISS_HINT:.0%}, **保留不删除**, 请人工判断是否有信息价值): ",
            f"⚠️ High-missing columns (missing rate >{cfg.HIGH_MISS_HINT:.0%}, **kept, not dropped**; please judge their information value manually): ")
        log("; ".join(f"{c}({train_df[c].isna().mean():.0%})" for c in high_miss) + "\n")

    # 2b 离群截断 (分位数取自训练集)
    clip_bounds = {}
    for c in num_cols:
        lo, hi = train_df[c].quantile(cfg.CLIP_LOW), train_df[c].quantile(cfg.CLIP_HIGH)
        clip_bounds[c] = (lo, hi)
        train_df[c] = train_df[c].clip(lo, hi)
        test_df[c] = test_df[c].clip(lo, hi)
        prep_log.append([c, "离群截断", f"[{lo:.4g}, {hi:.4g}] ({cfg.CLIP_LOW:.0%}/{cfg.CLIP_HIGH:.0%}分位)",
                         "Outlier clip"])

    # 2c 缺失填充 —— 基于数据探索给出建议; 支持全局策略与按列覆盖 (填充值取自训练集)
    fill_vals = {}
    impute_report = []     # 中文: [列, 缺失率, 采用策略, 填充值, 建议依据/来源]
    impute_report_en = []  # 英文
    for c in num_cols:
        mr = train_df[c].isna().mean()
        if mr == 0 and test_df[c].isna().mean() == 0:
            continue  # 无缺失, 跳过
        # 决定策略: 按列覆盖 > 全局显式 > auto 建议
        if c in impute_overrides:
            strat, reason_zh, reason_en = impute_overrides[c], "用户按列指定", "user per-column override"
        elif args.impute != "auto":
            strat, reason_zh, reason_en = args.impute, f"用户全局指定({args.impute})", f"user global setting ({args.impute})"
        else:
            strat, reason_zh, reason_en = suggest_impute_strategy(train_df[c], c)
        v = compute_fill_value(train_df[c], strat)
        fill_vals[c] = (strat, v)
        train_df[c] = train_df[c].fillna(v)
        test_df[c] = test_df[c].fillna(v)
        impute_report.append([c, f"{mr:.1%}", strat, f"{v:.4g}", reason_zh])
        impute_report_en.append([c, f"{mr:.1%}", strat, f"{v:.4g}", reason_en])

    if impute_report:
        log("缺失值处理明细(基于数据探索的填充建议):\n",
            "Missing-value handling details (imputation suggested from data exploration):\n")
        log(pd.DataFrame(impute_report,
                         columns=["特征", "缺失率", "填充策略", "填充值", "依据/来源"]).to_markdown(index=False) + "\n",
            pd.DataFrame(impute_report_en,
                         columns=["Feature", "Missing rate", "Strategy", "Fill value", "Rationale/source"]).to_markdown(index=False) + "\n")
    else:
        log("(数值特征无缺失, 无需填充)\n", "(No missing values in numeric features; no imputation needed)\n")

    # 2d 类别 One-Hot (基于训练集类别)
    if cat_cols:
        train_df = pd.get_dummies(train_df, columns=cat_cols, dummy_na=False)
        test_df = pd.get_dummies(test_df, columns=cat_cols, dummy_na=False)
        # 对齐列
        train_df, test_df = train_df.align(test_df, join="left", axis=1, fill_value=0)
        num_cols = [c for c in train_df.columns if c not in drop_cols and pd.api.types.is_numeric_dtype(train_df[c]) and c != target]

    log("预处理动作汇总:\n", "Preprocessing actions summary:\n")
    log(pd.DataFrame([[r[0], r[1], r[2]] for r in prep_log],
                     columns=["特征", "动作", "参数/原因"]).to_markdown(index=False) + "\n",
        pd.DataFrame([[r[0], r[3], r[2]] for r in prep_log],
                     columns=["Feature", "Action", "Params/reason"]).to_markdown(index=False) + "\n")

    # ============ Step 3 特征构造 ============
    log("## Step 3 · 特征构造\n", "## Step 3 · Feature Construction\n")
    log(f"特征构造模式: **{args.feature_mode}** "
        f"(auto=自动交互/多项式, custom=仅自定义公式, both=两者叠加)\n",
        f"Feature construction mode: **{args.feature_mode}** "
        f"(auto=auto interactions/polynomials, custom=user formulas only, both=stack both)\n")
    construct_log = []  # [新特征, 方式代码, 来源特征, 构造公式]
    # 方式代码 -> (中文, 英文) 便于双语渲染
    METHOD_LABELS = {
        "custom":  ("用户自定义", "user-defined"),
        "poly":    ("自动·多项式(平方)", "auto · polynomial (square)"),
        "inter":   ("自动·交互项", "auto · interaction"),
        "lag":     ("自动·滞后项(lag)", "auto · lag"),
        "roll":    ("自动·滑动均值(rolling)", "auto · rolling mean"),
    }
    # 选参与自动构造的基础特征: 与 target 相关性最高的前 N 个数值特征
    corr_with_t = train_df[num_cols].corrwith(train_df[target]).abs().sort_values(ascending=False)
    base_feats = list(corr_with_t.head(cfg.MAX_BASE_FOR_CONSTRUCT).index)

    # ---- 模式(1): 用户自定义特征 (公式在输入中给出) ----
    if args.feature_mode in ("custom", "both"):
        custom_specs = parse_custom_features(args.custom_features)
        if not custom_specs:
            log("⚠️ 特征模式包含 custom, 但未提供 --custom-features, 跳过自定义构造。\n",
                "⚠️ Mode includes custom, but --custom-features not provided; skipping custom construction.\n")
        for newc, expr in custom_specs:
            try:
                train_df[newc] = train_df.eval(expr)
                test_df[newc] = test_df.eval(expr)
                construct_log.append([newc, "custom", "用户指定 / user-specified", expr])
            except Exception as e:
                log(f"⚠️ 自定义特征 `{newc}` 构造失败(表达式: {expr}): {e}\n",
                    f"⚠️ Custom feature `{newc}` failed (expr: {expr}): {e}\n")

    # ---- 模式(2): 自动化交互项 / 多项式 ----
    if args.feature_mode in ("auto", "both"):
        if cfg.MAKE_POLY:
            for c in base_feats:
                newc = f"{c}__sq"
                train_df[newc] = train_df[c] ** 2
                test_df[newc] = test_df[c] ** 2
                construct_log.append([newc, "poly", c, f"{c}^2"])

        if cfg.MAKE_INTERACTIONS:
            # 只在数值特征间构造交互项 (避免 one-hot 互斥列相乘产生退化列)
            inter_base = [c for c in base_feats if train_df[c].nunique() > 2]

            # 生成候选特征对: 手动指定优先, 否则自动两两组合
            manual_pairs = parse_interaction_pairs(args.interaction_pairs)
            if manual_pairs:
                cand_pairs = [(a, b) for a, b in manual_pairs
                              if a in train_df.columns and b in train_df.columns]
                skipped_missing = [(a, b) for a, b in manual_pairs
                                   if a not in train_df.columns or b not in train_df.columns]
                for a, b in skipped_missing:
                    log(f"⚠️ 手动交互对 `{a}*{b}` 中有列不存在, 已跳过。\n",
                        f"⚠️ Manual interaction pair `{a}*{b}` has a missing column; skipped.\n")
            else:
                cand_pairs = [(inter_base[i], inter_base[j])
                              for i in range(len(inter_base))
                              for j in range(i + 1, len(inter_base))]

            allow_same_family = args.allow_same_family or (not cfg.INTER_SKIP_SAME_FAMILY)
            inter_skip_log = []   # 记录被过滤掉的对及原因 [pair, reason_zh, reason_en]
            scored = []           # [(gain, newc, a, b, corr_new)]
            for a, b in cand_pairs:
                # 闸1: 同族过滤 (revenue_q1 × revenue_q2 这类无业务含义组合)
                if not allow_same_family and feature_family(a) == feature_family(b):
                    inter_skip_log.append([f"{a} × {b}",
                                           f"同族特征(词根均为 '{feature_family(a)}'), 相乘无业务含义",
                                           f"same family (root '{feature_family(a)}'), product has no business meaning"])
                    continue
                # 闸2: 两母特征高共线过滤 (相乘只会加剧多重共线性)
                try:
                    pair_corr = abs(train_df[a].corr(train_df[b]))
                except Exception:
                    pair_corr = 0.0
                if not manual_pairs and pair_corr > cfg.INTER_SKIP_HIGH_CORR:
                    inter_skip_log.append([f"{a} × {b}",
                                           f"两母特征高度相关(|r|={pair_corr:.2f}>{cfg.INTER_SKIP_HIGH_CORR}), 相乘加剧共线性",
                                           f"parents highly correlated (|r|={pair_corr:.2f}>{cfg.INTER_SKIP_HIGH_CORR}), product worsens collinearity"])
                    continue
                # 闸3: 增益校验 (交互项须比两母特征各自更相关, 否则无信息增量)
                prod = train_df[a] * train_df[b]
                if prod.nunique() <= 1 or prod.isna().all():
                    inter_skip_log.append([f"{a} × {b}", "乘积为常数或全 NaN, 退化项",
                                           "product is constant or all-NaN, degenerate term"])
                    continue
                corr_new = abs(prod.corr(train_df[target]))
                corr_a = abs(train_df[a].corr(train_df[target]))
                corr_b = abs(train_df[b].corr(train_df[target]))
                gain = corr_new - max(corr_a, corr_b)
                if not manual_pairs and gain < cfg.INTER_MIN_GAIN:
                    inter_skip_log.append([f"{a} × {b}",
                                           f"无信息增益(交互|r|={corr_new:.2f} 未超母特征 max|r|={max(corr_a, corr_b):.2f}+{cfg.INTER_MIN_GAIN})",
                                           f"no info gain (interaction |r|={corr_new:.2f} not above parent max|r|={max(corr_a, corr_b):.2f}+{cfg.INTER_MIN_GAIN})"])
                    continue
                scored.append((gain, f"{a}__x__{b}", a, b, corr_new))

            # 闸4: 按增益排序, 只保留 Top-K, 防维度爆炸
            scored.sort(key=lambda t: t[0], reverse=True)
            kept = scored if manual_pairs else scored[:cfg.INTER_MAX_KEEP]
            if not manual_pairs:
                for s in scored[cfg.INTER_MAX_KEEP:]:
                    inter_skip_log.append([f"{s[2]} × {s[3]}",
                                           f"增益排序在 Top-{cfg.INTER_MAX_KEEP} 之外",
                                           f"outside Top-{cfg.INTER_MAX_KEEP} by gain ranking"])
            for gain, newc, a, b, corr_new in kept:
                train_df[newc] = train_df[a] * train_df[b]
                test_df[newc] = test_df[a] * test_df[b]
                construct_log.append([newc, "inter", f"{a}, {b}",
                                      f"{a} × {b} (|r|target={corr_new:.2f}, gain+{gain:.2f})"])

            if inter_skip_log:
                log(f"**自动交互项已过滤 {len(inter_skip_log)} 个无意义/冗余组合**"
                    f"(同族/高共线/无增益/超上限):\n",
                    f"**Filtered out {len(inter_skip_log)} meaningless/redundant auto interactions** "
                    f"(same-family / high-collinearity / no-gain / over-cap):\n")
                log(pd.DataFrame([[r[0], r[1]] for r in inter_skip_log],
                                 columns=["被跳过的特征对", "跳过原因"]).to_markdown(index=False) + "\n",
                    pd.DataFrame([[r[0], r[2]] for r in inter_skip_log],
                                 columns=["Skipped pair", "Reason"]).to_markdown(index=False) + "\n")

    if is_ts and args.feature_mode in ("auto", "both"):
        # 时间序列衍生: 滞后 + 滑动均值 (只用过去信息)
        for c in base_feats[:3]:
            train_df[f"{c}__lag1"] = train_df[c].shift(1)
            test_df[f"{c}__lag1"] = test_df[c].shift(1)
            train_df[f"{c}__roll3"] = train_df[c].shift(1).rolling(3).mean()
            test_df[f"{c}__roll3"] = test_df[c].shift(1).rolling(3).mean()
            construct_log.append([f"{c}__lag1", "lag", c, f"{c}(t-1)"])
            construct_log.append([f"{c}__roll3", "roll", c, f"mean({c}, t-1..t-3)"])
        # lag/roll 造成的头部缺失, 用中位数补
        train_df = train_df.fillna(train_df.median(numeric_only=True))
        test_df = test_df.fillna(train_df.median(numeric_only=True))

    # 剔除构造后产生的常数列/全 NaN 列 (退化特征)
    for c in [x[0] for x in construct_log]:
        if c in train_df.columns and (train_df[c].nunique(dropna=True) <= 1):
            train_df.drop(columns=[c], inplace=True, errors="ignore")
            test_df.drop(columns=[c], inplace=True, errors="ignore")
    construct_log = [r for r in construct_log if r[0] in train_df.columns]

    if construct_log:
        log("构造特征清单:\n", "Constructed feature list:\n")
        log(pd.DataFrame([[r[0], METHOD_LABELS.get(r[1], (r[1], r[1]))[0], r[2], r[3]] for r in construct_log],
                         columns=["新特征", "构造方式", "来源特征", "构造公式"]).to_markdown(index=False) + "\n",
            pd.DataFrame([[r[0], METHOD_LABELS.get(r[1], (r[1], r[1]))[1], r[2], r[3]] for r in construct_log],
                         columns=["New feature", "Method", "Source feature(s)", "Formula"]).to_markdown(index=False) + "\n")
    else:
        log("(未构造新特征)\n", "(No new features constructed)\n")

    # 更新特征全集
    all_feats = [c for c in train_df.columns if c not in drop_cols and c != target and pd.api.types.is_numeric_dtype(train_df[c])]

    # ============ Step 4 相关性分析 ============
    log("## Step 4 · 相关性分析\n", "## Step 4 · Correlation Analysis\n")
    corr = train_df[all_feats + [target]].corr()
    _sz = min(20, 1 + 0.5 * len(all_feats))
    fig, ax = plt.subplots(figsize=(_sz, _sz))
    sns.heatmap(corr, cmap="coolwarm", center=0, annot=False,
                cbar_kws={"label": L("相关系数 r", "Correlation r")}, ax=ax)
    ax.set_title(L("特征相关性热力图(Pearson r)", "Feature Correlation Heatmap (Pearson r)"),
                 fontproperties=ZH_FP)
    for lab in ax.get_xticklabels() + ax.get_yticklabels():
        lab.set_fontproperties(ZH_FP)
    savefig("03_corr_heatmap.png")
    log("![heatmap](03_corr_heatmap.png)\n")
    log("各特征与 target 的相关系数(降序):\n", "Correlation of each feature with the target (descending):\n")
    ct = corr[target].drop(target).sort_values(key=lambda s: s.abs(), ascending=False)
    log(ct.round(4).to_frame("corr_with_target").to_markdown() + "\n")

    # 特征-目标相关性条形图 (Top 20, 更直观)
    ct_top = ct.reindex(ct.abs().sort_values(ascending=False).index).head(20)
    fig, ax = plt.subplots(figsize=(8, max(3, 0.4 * len(ct_top))))
    _colors = ["#d1615d" if v >= 0 else "#5778a4" for v in ct_top.values]
    ax.barh(range(len(ct_top)), ct_top.values, color=_colors)
    ax.set_yticks(range(len(ct_top)))
    ax.set_yticklabels(ct_top.index, fontproperties=ZH_FP)
    ax.invert_yaxis()
    ax.axvline(0, color="gray", lw=0.8)
    ax.set_title(L(f"各特征与 {target} 的相关系数(Top {len(ct_top)})",
                   f"Feature vs {target} correlation (Top {len(ct_top)})"), fontproperties=ZH_FP)
    ax.set_xlabel(L("与目标的相关系数 r(红=正相关, 蓝=负相关)",
                    "Correlation r with target (red=+, blue=-)"), fontproperties=ZH_FP)
    ax.set_ylabel(L("特征", "Feature"), fontproperties=ZH_FP)
    savefig("03b_feat_corr.png")
    log("![feat_corr](03b_feat_corr.png)\n")
    _tc = ct.reindex(ct.abs().sort_values(ascending=False).index).head(3)
    _hz, _he = explain_chart("heatmap", args.context, args.goal, target=target,
                             top_corr="、".join(f"`{k}`(r={v:.2f})" for k, v in _tc.items()))
    # 英文解读里的 top_corr 用英文顿号替换
    _he = _he.replace("、".join(f"`{k}`(r={v:.2f})" for k, v in _tc.items()),
                      ", ".join(f"`{k}` (r={v:.2f})" for k, v in _tc.items()))
    log(_hz, _he)

    # ============ Step 5 去除冗余特征 ============
    log("## Step 5 · 去除冗余特征\n", "## Step 5 · Redundant Feature Removal\n")
    removed = []
    kept = list(all_feats)

    # 5a 与 target 低相关
    low = [c for c in kept if abs(corr.loc[c, target]) < cfg.CORR_TARGET_MIN]
    for c in low:
        _r = f"|r|={abs(corr.loc[c,target]):.3f} < {cfg.CORR_TARGET_MIN}"
        removed.append([c, "与target低相关", _r, "low corr with target", _r])
    kept = [c for c in kept if c not in low]

    # 5b 特征间高相关, 保留与target相关性更高者
    to_drop = set()
    for i in range(len(kept)):
        for j in range(i + 1, len(kept)):
            a, b = kept[i], kept[j]
            if a in to_drop or b in to_drop:
                continue
            r = abs(corr.loc[a, b])
            if r > cfg.CORR_HIGH:
                drop_one = a if abs(corr.loc[a, target]) < abs(corr.loc[b, target]) else b
                keep_one = b if drop_one == a else a
                to_drop.add(drop_one)
                removed.append([drop_one, "特征间高相关",
                                f"与 {keep_one} |r|={r:.3f}>{cfg.CORR_HIGH}, 保留与target更相关者",
                                "inter-feature high corr",
                                f"|r|={r:.3f}>{cfg.CORR_HIGH} with {keep_one}; kept the one more correlated with target"])
    kept = [c for c in kept if c not in to_drop]

    # 5c VIF 迭代剔除
    def compute_vif(cols):
        X = sm.add_constant(train_df[cols].astype(float))
        return {cols[i]: variance_inflation_factor(X.values, i + 1) for i in range(len(cols))}

    while len(kept) > 1:
        vifs = compute_vif(kept)
        worst = max(vifs, key=vifs.get)
        if vifs[worst] > cfg.VIF_THRESH:
            _r = f"VIF={vifs[worst]:.1f} > {cfg.VIF_THRESH}"
            removed.append([worst, "多重共线性(VIF)", _r, "multicollinearity (VIF)", _r])
            kept.remove(worst)
        else:
            break

    if removed:
        log("去除的冗余特征及原因:\n", "Removed redundant features and reasons:\n")
        log(pd.DataFrame([[r[0], r[1], r[2]] for r in removed],
                         columns=["特征", "去除类别", "原因"]).to_markdown(index=False) + "\n",
            pd.DataFrame([[r[0], r[3], r[4]] for r in removed],
                         columns=["Feature", "Category", "Reason"]).to_markdown(index=False) + "\n")
    else:
        log("(无冗余特征被去除)\n", "(No redundant features removed)\n")

    # ============ Step 6 基于优化目标的特征选择 ============
    log("## Step 6 · 特征选择\n", "## Step 6 · Feature Selection\n")
    log(f"以优化目标 **{opt_metric}** 为准, 在训练集上做交叉验证后向剔除: "
        f"逐一尝试移除某特征, 若能改善 CV {opt_metric} 则移除, 直至无法改善。\n",
        f"Guided by the optimization metric **{opt_metric}**, backward elimination via cross-validation on the training set: "
        f"try removing each feature; drop it if CV {opt_metric} improves, until no further improvement.\n")

    from sklearn.model_selection import TimeSeriesSplit, KFold

    def _metric_val(y, p, k):
        r2 = r2_score_(y, p)
        return {"WMAPE": wmape(y, p), "MAE": mae(y, p), "RMSE": rmse(y, p),
                "R2": r2, "Adj_R2": adjusted_r2(r2, len(y), k)}[opt_metric]

    def cv_score(cols):
        """在训练集上用 CV 计算选定优化指标, 逐折评估后平均 (返回统一为 loss, 越小越好)"""
        if not cols:
            return np.inf
        splitter = TimeSeriesSplit(n_splits=4) if is_ts else KFold(n_splits=4, shuffle=True, random_state=42)
        Xc = train_df[cols].values
        yc = train_df[target].values
        fold_vals = []
        for tr_idx, va_idx in splitter.split(Xc):
            sc = StandardScaler().fit(Xc[tr_idx])
            # 训练用变换后的 y, 预测后还原到原始尺度再评估
            mdl = LinearRegression().fit(sc.transform(Xc[tr_idx]), y_fwd(yc[tr_idx]))
            pv = y_inv(mdl.predict(sc.transform(Xc[va_idx])))
            fold_vals.append(_metric_val(yc[va_idx], pv, len(cols)))
        val = float(np.nanmean(fold_vals))
        return val if opt_lower_better else -val  # 统一成 loss (越小越好)

    sel_removed = []
    best_loss = cv_score(kept)
    improved = True
    while improved and len(kept) > 1:
        improved = False
        for c in list(kept):
            trial = [x for x in kept if x != c]
            loss = cv_score(trial)
            if loss < best_loss - 1e-9:
                best_loss = loss
                kept = trial
                sel_removed.append([c, f"移除后 CV {opt_metric} 改善", f"removing improves CV {opt_metric}"])
                improved = True
                break
    if sel_removed:
        log(f"基于 {opt_metric} 剔除的特征:\n", f"Features removed based on {opt_metric}:\n")
        log(pd.DataFrame([[r[0], r[1]] for r in sel_removed],
                         columns=["特征", "原因"]).to_markdown(index=False) + "\n",
            pd.DataFrame([[r[0], r[2]] for r in sel_removed],
                         columns=["Feature", "Reason"]).to_markdown(index=False) + "\n")
    else:
        log(f"(所有特征均对 {opt_metric} 有贡献, 未再剔除)\n",
            f"(All features contribute to {opt_metric}; none removed)\n")

    # ============ Step 6.1 最终特征 ============
    log("### 最终选择的特征\n", "### Final Selected Features\n")
    log(f"共 {len(kept)} 个特征:\n", f"{len(kept)} features in total:\n")
    log("```\n" + "\n".join(kept) + "\n```\n")

    # ============ Step 7 建模 + 评估 ============
    log("## Step 7 · 线性回归建模与评估\n", "## Step 7 · Linear Regression Modeling & Evaluation\n")
    scaler = StandardScaler().fit(train_df[kept])
    Xtr = scaler.transform(train_df[kept]); Xte = scaler.transform(test_df[kept])
    ytr = train_df[target].values; yte = test_df[target].values

    # 训练用变换后的 y (log1p if use_log); 预测结果用 expm1 还原到原始尺度
    model = LinearRegression().fit(Xtr, y_fwd(ytr))
    pred_tr = y_inv(model.predict(Xtr)); pred_te = y_inv(model.predict(Xte))
    if use_log:
        log(f"> 目标已做 **log1p 变换**训练, 预测结果已 **expm1 还原**至原始尺度; 以下指标均为原始尺度。\n",
            f"> The target was trained with a **log1p transform**; predictions are **reverted with expm1** to the original scale; all metrics below are on the original scale.\n")

    def metrics(y, p, n, k):
        r2 = r2_score_(y, p)
        return dict(WMAPE=wmape(y, p), MAE=mae(y, p), RMSE=rmse(y, p),
                    R2=r2, Adj_R2=adjusted_r2(r2, n, k))

    m_tr = metrics(ytr, pred_tr, len(ytr), len(kept))
    m_te = metrics(yte, pred_te, len(yte), len(kept))
    mt_zh = pd.DataFrame({"训练集": m_tr, "测试集": m_te}).round(4)
    mt_en = pd.DataFrame({"Train": m_tr, "Test": m_te}).round(4)
    log(f"**模型优化目标指标: `{opt_metric}`** ({'越小越好' if opt_lower_better else '越大越好'}) — "
        f"特征选择方向与最优模型判定均以该指标为准。\n",
        f"**Optimization metric: `{opt_metric}`** ({'lower is better' if opt_lower_better else 'higher is better'}) — "
        f"both feature-selection direction and best-model choice follow this metric.\n")
    log("评价指标(★ 为选定的优化目标):\n", "Evaluation metrics (★ = the chosen optimization metric):\n")
    # 在优化目标指标行加标记
    mt_zh.index = [f"★ {i}" if i == opt_metric else i for i in mt_zh.index]
    mt_en.index = [f"★ {i}" if i == opt_metric else i for i in mt_en.index]
    log(mt_zh.to_markdown() + "\n", mt_en.to_markdown() + "\n")
    log(f"→ 本模型在测试集上的优化目标 **{opt_metric} = {m_te[opt_metric]:.4f}**\n",
        f"→ On the test set, the model's optimization metric **{opt_metric} = {m_te[opt_metric]:.4f}**\n")

    # 模型公式 (标准化系数)
    log("### 线性回归模型公式(基于标准化特征)\n", "### Linear Regression Formula (on standardized features)\n")
    lhs = f"log1p({target})" if use_log else target
    terms = [f"{model.intercept_:.4f}"] + [f"({coef:+.4f})·{name}" for name, coef in zip(kept, model.coef_)]
    log("```\n" + f"{lhs} = " + " + ".join(terms).replace("+ (-", "- (") + "\n```")
    if use_log:
        log(f"（预测时对上式结果取 expm1 还原:  {target} = expm1( 上式 ) ）\n",
            f"(At prediction, revert the above with expm1:  {target} = expm1( formula above ) )\n")
    else:
        log("")

    # 系数表 (含 p 值, 用 statsmodels 复核; 与建模一致, 基于变换后的 y)
    Xtr_sm = sm.add_constant(pd.DataFrame(Xtr, columns=kept))
    ols = sm.OLS(y_fwd(ytr), Xtr_sm).fit()
    coef_tbl = pd.DataFrame({
        "coef": ols.params, "std_err": ols.bse, "p_value": ols.pvalues,
        "CI_low": ols.conf_int()[0], "CI_high": ols.conf_int()[1],
    }).round(4)
    log(f"系数表(标准化特征{', 目标为 log1p 尺度' if use_log else ''}, 含 p 值与置信区间):\n",
        f"Coefficient table (standardized features{', target on log1p scale' if use_log else ''}, with p-values and CIs):\n")
    log(coef_tbl.to_markdown() + "\n")

    # 残差诊断
    resid = yte - pred_te
    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    ax[0].scatter(pred_te, resid, s=10); ax[0].axhline(0, color="r", ls="--")
    ax[0].set_xlabel(L(f"拟合值(预测 {target})", f"Fitted ({target} predicted)"), fontproperties=ZH_FP)
    ax[0].set_ylabel(L("残差(真实 − 预测)", "Residual (actual − predicted)"), fontproperties=ZH_FP)
    ax[0].set_title(L("残差 vs 拟合值(应随机散布于 0 线两侧)",
                      "Residuals vs Fitted (should scatter around 0)"), fontproperties=ZH_FP)
    ax[0].xaxis.set_major_formatter(HUMAN_FMT); ax[0].yaxis.set_major_formatter(HUMAN_FMT)
    sm.qqplot(resid, line="s", ax=ax[1])
    ax[1].set_title(L("残差 Q-Q 图(点贴红线=近似正态)",
                      "Residual Q-Q Plot (on line = normal)"), fontproperties=ZH_FP)
    ax[1].set_xlabel(L("理论分位数", "Theoretical Quantiles"), fontproperties=ZH_FP)
    ax[1].set_ylabel(L("样本分位数", "Sample Quantiles"), fontproperties=ZH_FP)
    ax[1].yaxis.set_major_formatter(HUMAN_FMT)
    savefig("04_residual.png")
    log("![residual](04_residual.png)\n")
    # 异方差简易检测: 按拟合值分两半, 比较残差方差, 差异大则提示发散
    _hetero = False
    try:
        _order = np.argsort(pred_te)
        _h = resid[_order]
        _half = len(_h) // 2
        if _half >= 5:
            _v_low = np.nanvar(_h[:_half]); _v_high = np.nanvar(_h[_half:])
            _hetero = (_v_high > 3 * _v_low) or (_v_low > 3 * _v_high)
    except Exception:
        _hetero = False
    _rz, _re = explain_chart("residual", args.context, args.goal, heterosced=_hetero)
    log(_rz, _re)

    # ---------- 产物落盘 ----------
    test_df.head(50).to_csv(os.path.join(args.outdir, "processed_head50.csv"), index=False)
    with open(os.path.join(args.outdir, "model.pkl"), "wb") as f:
        pickle.dump({"model": model, "scaler": scaler, "features": kept,
                     "clip_bounds": clip_bounds, "fill_vals": fill_vals,
                     "use_log_target": use_log}, f)
    with open(os.path.join(args.outdir, "report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(REPORT))
    with open(os.path.join(args.outdir, "report_en.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(REPORT_EN))

    log(f"\n---\n产物已保存至: {os.path.abspath(args.outdir)}/  "
        f"(report.md 中文 / report_en.md 英文 / *.png / processed_head50.csv / model.pkl)",
        f"\n---\nArtifacts saved to: {os.path.abspath(args.outdir)}/  "
        f"(report.md ZH / report_en.md EN / *.png / processed_head50.csv / model.pkl)")


if __name__ == "__main__":
    main()
